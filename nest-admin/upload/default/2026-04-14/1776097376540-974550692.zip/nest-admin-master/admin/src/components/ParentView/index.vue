<template>
	<router-view />
</template>
